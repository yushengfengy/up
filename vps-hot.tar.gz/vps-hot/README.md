# vps-hot

零依赖 VPS 热点聚合器，已在 Railway 部署： https://vps-hot-production.up.railway.app/

## 功能
- 支持 rss / json_list / web_list 三种来源
- 自动评分、去重、按标题聚簇
- 域限速 + 429 退避重试
- / /rss /api/items /api/sources /api/ingest
- 5分钟一轮检查过期来源
- data/ 目录挂卷持久化

## 本地运行
```bash
tar xzf vps-hot.tar.gz
cd vps-hot
PORT=8080 INGEST_TOKEN=你的密钥 node server.mjs
# 打开 http://localhost:8080
```

## Railway 部署
```bash
cd vps-hot
railway up --service vps-hot --detach
# 在 Railway 变量里设置 INGEST_TOKEN
# 挂卷：Add Volume -> Mount Path /app/data
```

## 处理 Reddit 429
Reddit 对云服务器IP限流严重，已停用：
- reddit-VPS
- reddit-oraclecloud
- reddit-lowendbox

解决办法：
1. interval_minutes 改成 360 (6小时) - 已做
2. 换成 RSSHub 自建或 RSS代理
3. enabled: false 彻底关闭

改完 sources.json 后重新 railway up
