// server.mjs - HTTP 服务，无依赖
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { collectOnce } from './collector.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'items.json');
const STATUS_FILE = path.join(DATA_DIR, 'sources_status.json');

const PORT = parseInt(process.env.PORT || '8080', 10);
const TOKEN = process.env.INGEST_TOKEN || '';
const PUBLIC_DOMAIN = process.env.RAILWAY_PUBLIC_DOMAIN || '';

function loadJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; }
}
function saveJson(p, obj) {
  if (!fs.existsSync(path.dirname(p))) fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), 'utf8');
}

function htmlPage(items, status) {
  const rows = items.slice(0, 100).map(it => {
    const age = Math.round((Date.now() - new Date(it.createdAt).getTime())/3600000);
    return `<div class="item">
      <div class="score">${it.score}</div>
      <div class="main">
        <a href="${it.url}" target="_blank" rel="noopener">${escapeHtml(it.title)}</a>
        <div class="meta">${it.source} · ${age}h ago · ${escapeHtml(it.description||'').slice(0,120)}</div>
      </div>
    </div>`;
  }).join('');

  const srcRows = Object.entries(status).map(([id, s]) => {
    const color = s.error ? '#ef4444' : s.enabled === false ? '#9ca3af' : '#22c55e';
    const text = s.enabled === false ? '暂停' : s.error ? s.error : `OK ${s.lastCount||0}/${s.lastTotal||0}`;
    return `<tr><td>${id}</td><td><span style="color:${color}">●</span> ${text}</td><td>${s.lastFetch||'-'}</td></tr>`;
  }).join('');

  return `<!doctype html><html lang="zh"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>vps-hot - VPS 热点聚合</title>
<style>
body{font-family:ui-sans,system-ui, -apple-system; max-width:900px; margin:0 auto; padding:20px; background:#fafafa; color:#111}
h1{font-size:24px} .item{display:flex; gap:12px; padding:12px; background:#fff; border:1px solid #eee; border-radius:10px; margin:8px 0}
.score{min-width:42px; height:32px; background:#111; color:#fff; display:grid; place-items:center; border-radius:8px; font-weight:600}
.main a{font-weight:600; color:#111; text-decoration:none} .main a:hover{text-decoration:underline}
.meta{font-size:12px; color:#666; margin-top:4px}
table{width:100%; border-collapse:collapse; font-size:13px; margin-top:12px}
td,th{border:1px solid #eee; padding:6px 8px; text-align:left; background:#fff}
.badge{display:inline-block; padding:2px 8px; border-radius:999px; background:#e5e7eb; font-size:12px; margin-right:6px}
code{background:#eee; padding:2px 6px; border-radius:6px}
</style></head><body>
<h1>vps-hot 🔥 <span class="badge">${items.length} 条</span></h1>
<p>聚合 LowEndBox / LowEndTalk / NodeSeek / Reddit VPS 板块。分数按 <code>rules.json</code> 规则 + 时间半衰期计算。
<a href="/rss">RSS</a> · <a href="/api/items">/api/items</a> · <a href="/api/sources">/api/sources</a></p>
<div>${rows || '<p>正在抓取中，稍后刷新...</p>'}</div>
<h2>来源状态</h2>
<table><tr><th>来源</th><th>状态</th><th>最后抓取</th></tr>${srcRows}</table>
<footer style="margin-top:24px; font-size:12px; color:#999">PORT=${PORT} · data卷: ${DATA_DIR} · 试用地址仅限自己IP可访问，Railway部署后公开</footer>
</body></html>`;
}
function escapeHtml(s){ return s.replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  try {
    if (url.pathname === '/' || url.pathname === '/index.html') {
      const items = loadJson(DATA_FILE, []);
      const status = loadJson(STATUS_FILE, {});
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(htmlPage(items, status));
    } else if (url.pathname === '/rss') {
      const items = loadJson(DATA_FILE, []).slice(0, 50);
      const rss = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>vps-hot</title><link>https://${PUBLIC_DOMAIN || req.headers.host}</link><description>VPS热点聚合</description>${items.map(it=>`<item><title><![CDATA[${it.title}]]></title><link>${it.url}</link><guid>${it.url}</guid><pubDate>${new Date(it.createdAt).toUTCString()}</pubDate><description><![CDATA[${it.description||''} score:${it.score} source:${it.source}]]></description></item>`).join('')}</channel></rss>`;
      res.writeHead(200, { 'Content-Type': 'application/rss+xml; charset=utf-8' });
      res.end(rss);
    } else if (url.pathname === '/api/items') {
      const items = loadJson(DATA_FILE, []);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ count: items.length, items }, null, 2));
    } else if (url.pathname === '/api/sources') {
      const status = loadJson(STATUS_FILE, {});
      const sources = loadJson(path.join(__dirname, 'sources.json'), []);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ sources, status }, null, 2));
    } else if (url.pathname === '/api/ingest' && req.method === 'POST') {
      if (TOKEN) {
        const auth = req.headers.authorization || '';
        if (auth !== `Bearer ${TOKEN}`) {
          res.writeHead(401, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'unauthorized' }));
          return;
        }
      }
      let body = '';
      for await (const chunk of req) body += chunk;
      const incoming = JSON.parse(body || '{}');
      const list = Array.isArray(incoming) ? incoming : incoming.items || [incoming];
      const existing = loadJson(DATA_FILE, []);
      let added = 0;
      for (const it of list) {
        if (!it.title || !it.url) continue;
        if (existing.some(e=> e.url===it.url)) continue;
        existing.push({ id: `ingest:${Date.now()}:${added}`, title: it.title, url: it.url, source: it.source||'ingest', score: it.score||20, rawScore: it.score||20, createdAt: new Date().toISOString(), fetchedAt: new Date().toISOString(), description: it.description||'' });
        added++;
      }
      saveJson(DATA_FILE, existing.slice(-500));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, added }));
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('not found');
    }
  } catch (e) {
    console.error(e);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('error: '+e.message);
  }
});

server.listen(PORT, () => {
  console.log(`[server] listening on :${PORT}  token:${TOKEN?'set':'none'}  domain:${PUBLIC_DOMAIN||'local'}`);
  // 启动立即抓一次
  collectOnce().catch(console.error);
});

// 每5分钟检查到期来源
setInterval(() => {
  collectOnce().catch(console.error);
}, 5 * 60 * 1000);
